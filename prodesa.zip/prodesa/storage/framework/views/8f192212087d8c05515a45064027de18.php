

<?php $__env->startSection('content'); ?>
 <div class="d-sm-flex align-items-center justify-content-between mb-4">
    <h1 class="h3 mb-0 text-gray-800">Semua Notifikasi</h1>
    </div>

    <div class="row">
        <?php $__currentLoopData = auth()->user()->notifications; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $notification): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-12 mb-2">
            <div class="card shadow-sm">
                <div class="card-body" style="background-color: rgba(115, 194, 251, <?php echo e(is_null($notification->read_at) ? '0.1' : '0.0'); ?>);">
                    <div class="row">
                    <div class="col-1"><?php echo e($loop->iteration); ?></div>
                    <div class="col-9"><?php echo e($notification->data['message']); ?></div>
                    <?php if(is_null($notification->read_at)): ?>
                    <div class="col-2">
                        <form action="/notification/<?php echo e($notification->id); ?>/read" method="post">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('POST'); ?>
                            <button type="submit" class="btn btn-sm btn-primary btn-block">Tandai Baca</button>
                        </form>
                    </div>
                    <?php endif; ?>
                </div>
                </div>
            </div>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\latihanlaravel\resources\views/pages/notifications.blade.php ENDPATH**/ ?>