<!-- Modal -->
<div class="modal fade" id="confirdelete-<?php echo e($data->id); ?>" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="confirdeleteLabel" aria-hidden="true">
  <div class="modal-dialog">
    <form action="/resident/<?php echo e($data->id); ?>" method="post">
        <?php echo csrf_field(); ?>
        <?php echo method_field('DELETE'); ?>
        <div class="modal-content">
      <div class="modal-header">
        <h1 class="modal-title fs-5" id="confirdeleteLabel">Konfirmasi Hapus</h1>
        <button type="button" class="btn btn-default" data-bs-dismiss="modal" aria-label="Close">
          <i class="fas fa-times">
          </i>
        </button>
      </div>
      <div class="modal-body">
        <span>Yakin Ingin Mengapusnya?</span>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Tutup</button>
        <button type="submit" class="btn btn-outline-danger">Hapus</button>
      </div>
    </div>
    </form>
  </div>
</div><?php /**PATH C:\laragon\www\latihanlaravel\resources\views/pages/resident/confir-delete.blade.php ENDPATH**/ ?>