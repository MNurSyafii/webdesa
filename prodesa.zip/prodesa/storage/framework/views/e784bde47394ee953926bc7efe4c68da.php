<!-- Modal -->
<div class="modal fade" id="confirreject-<?php echo e($data->id); ?>" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="confirrejectLabel" aria-hidden="true">
  <div class="modal-dialog">
    <form action="/account-request/approval/<?php echo e($data->id); ?>" method="post">
        <?php echo csrf_field(); ?>
        <?php echo method_field('POST'); ?>
        <div class="modal-content">
      <div class="modal-header">
        <h1 class="modal-title fs-5" id="confirrejectLabel">Konfirmasi Nonatifkan</h1>
        <button type="button" class="btn btn-default" data-bs-dismiss="modal" aria-label="Close">
          <i class="fas fa-times">
          </i>
        </button>
      </div>
      
      <div class="modal-body">
        <input type="hidden" name="for" value="deactive">
        <span>Yakin Nonaktifkan Akun ini?</span>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Tutup</button>
        <button type="submit" class="btn btn-outline-danger">Ya</button>
      </div>
    </div>
    </form>
  </div>
</div><?php /**PATH C:\laragon\www\latihanlaravel\resources\views/pages/account-list/confir-reject.blade.php ENDPATH**/ ?>