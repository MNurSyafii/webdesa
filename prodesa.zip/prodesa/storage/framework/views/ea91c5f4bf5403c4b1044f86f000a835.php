

<?php $__env->startSection('content'); ?>
 <div class="d-sm-flex align-items-center justify-content-between mb-4">
    <h1 class="h3 mb-0 text-gray-800">List RW</h1>
          <a href="/rw-unit/create" class="d-none d-sm-inline-block btn btn-sm btn-primary shadow-sm"><i
         class="fas fa-plus fa-sm text-white-50"></i> Tambah </a>
    </div>

    <?php if(@session('success')): ?>
      <script>
        Swal.fire({
        title: "Berhasil",
        text: "<?php echo e(session()->get('success')); ?>",
        icon: "success"
        });
    </script>
    <?php endif; ?> 

    <?php if(@session('error')): ?>
      <script>
        Swal.fire({
        title: "Gagal",
        text: "<?php echo e(session()->get('error')); ?>",
        icon: "error"
        });
    </script>
    <?php endif; ?> 

    <div class="row">
        <div class="col">
            <div class="card shadow p-4">
                <div class="card-body">
                <table class="table table-bordered table-hovered" style="min-width: 100%">
                    <thead>
                        <tr>
                            <th>No</th>
                            <th>RW (Nomor)</th>
                            <th>Aksi</th>
                        </tr>
                    </thead>
                    <?php if(count($rw_units) < 1): ?>
                        <tbody>
                            <tr>
                                <td colspan="11">
                                    <p class="text-center">Tidak ada Data</p>
                                </td>
                            </tr>
                            <?php else: ?>
                            <tbody>
                        <?php $__currentLoopData = $rw_units; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                
                        <tr>
                            <td><?php echo e($loop->iteration + $rw_units->firstItem() - 1); ?></td>
                            <td>RW <?php echo e($data->number); ?></td>
                            <td>
                                <div class="d-flex align-items-center" style="gap: 5px">
                                    <a href="/rw-unit/<?php echo e($data->id); ?>" class="d-inline-block btn btn-sm btn-warning">
                                        <i  class="fas fa-pen"></i>
                                    </a>
                                    <button class="btn btn-sm btn-danger" data-bs-toggle="modal" data-bs-target="#confirdelete-<?php echo e($data->id); ?>">
                                        <i  class="fas fa-eraser"></i>
                                    </button>
                                </div>
                            </td> 
                            </tr>
                            <?php echo $__env->make('pages.rw-unit.confir-delete', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                    <?php endif; ?>
                </table>
            </div>
            <?php if($rw_units->lastPage()> 2): ?>
            <div class="card-footer">
                <?php echo e($rw_units->links('pagination::bootstrap-5')); ?>

            </div>
            <?php endif; ?>
            
        </div>
    </div>
    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\latihanlaravel\resources\views/pages/rw-unit/index.blade.php ENDPATH**/ ?>