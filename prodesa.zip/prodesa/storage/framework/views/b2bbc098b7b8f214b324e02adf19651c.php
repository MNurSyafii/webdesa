

<?php $__env->startSection('content'); ?>
 <div class="d-sm-flex align-items-center justify-content-between mb-4">
    <h1 class="h3 mb-0 text-gray-800">Permintaan Akun</h1>
    </div>

    <?php if(@session('success')): ?>
      <script>
        Swal.fire({
        title: "Berhasil",
        text: "<?php echo e(session()->get('success')); ?>",
        icon: "success"
        });
    </script>
    <?php endif; ?> 

    <div class="row">
        <div class="col">
            <div class="card shadow p-4">
                <div class="card-body">
                    <div style="overflow-x: auto">
                <table class="table table-bordered table-hovered" style="min-width: 100%">
                    <thead>
                        <tr>
                            <th>No</th>
                            <th>Nama</th>
                            <th>Email</th>
                            <th>Aksi</th>
                        </tr>
                    </thead>
                    <?php if(count($users) == 0): ?>
                        <tbody>
                            <tr>
                                <td colspan="11">
                                    <p class="text-center">Tidak ada Data</p>
                                </td>
                            </tr>
                            <?php else: ?>
                            <tbody>
                        <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                
                        <tr>
                            <td><?php echo e($loop->iteration + $users->firstItem() - 1); ?></td>
                            <td><?php echo e($data->name); ?></td>
                            <td><?php echo e($data->email); ?></td>
                            <td>
                                <div class="d-flex" style="gap: 5px">
                                    <button class="btn btn-sm btn-success" data-bs-toggle="modal" data-bs-target="#confirapprove-<?php echo e($data->id); ?>">
                                       Setujui
                                    </button>
                                    <button class="btn btn-sm btn-danger" data-bs-toggle="modal" data-bs-target="#confirreject-<?php echo e($data->id); ?>">
                                       Tolak
                                    </button>
                                </div>
                            </td>
                            </tr>
                            <?php echo $__env->make('pages.account-request.confir-approve', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                            <?php echo $__env->make('pages.account-request.confir-reject', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                    <?php endif; ?>
                </table>
                </div>
            </div>
             <?php if($users->lastPage()> 2): ?>
            <div class="card-footer">
                <?php echo e($users->links('pagination::bootstrap-5')); ?>

            </div>
            <?php endif; ?>
            
        </div>
    </div>
    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\latihanlaravel\resources\views/pages/account-request/index.blade.php ENDPATH**/ ?>