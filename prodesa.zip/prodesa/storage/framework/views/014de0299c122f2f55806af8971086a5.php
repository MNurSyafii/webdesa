

<?php $__env->startSection('content'); ?>
 <div class="d-sm-flex align-items-center justify-content-between mb-4">
    <h1 class="h3 mb-0 text-gray-800">Data Penduduk</h1>
      <a href="/resident/create" class="d-none d-sm-inline-block btn btn-sm btn-primary shadow-sm"><i
         class="fas fa-plus fa-sm text-white-50"></i> Tambah </a>
    </div>

    <div class="row">
        <div class="col">
            <div class="card shadow p-4">
                <div class="card-body">
                <table class="table table-responsive table-bordered table-hovered">
                    <thead>
                        <tr>
                            <th>No</th>
                            <th>NIK</th>
                            <th>Nama</th>
                            <th>Jenis Kelamin</th>
                            <th>TTL</th>
                            <th>Alamat</th>
                            <th>Agama</th>
                            <th>Status Perkawinan</th>
                            <th>Pekerjaan</th>
                            <th>Telepon</th>
                            <th>Status Penduduk</th>
                            <th>Aksi</th>
                        </tr>
                    </thead>
                    <?php if(count($residents) == 0): ?>
                        <tbody>
                            <tr>
                                <td colspan="11">
                                    <p class="text-center">Tidak ada Data</p>
                                </td>
                            </tr>
                            <?php else: ?>
                            <tbody>
                        <?php $__currentLoopData = $residents; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                
                        <tr>
                            <td><?php echo e($loop->iteration + $residents->firstItem() - 1); ?></td>
                            <td><?php echo e($data->nik); ?></td>
                            <td><?php echo e($data->name); ?></td>
                            <td><?php echo e($data->gender); ?></td>
                            <td><?php echo e($data->birth_place); ?>, <?php echo e($data->birth_date); ?></td>
                            <td><?php echo e($data->addres); ?></td>
                            <td><?php echo e($data->religion); ?></td>
                            <td><?php echo e($data->marital_status); ?></td>
                            <td><?php echo e($data->occupation); ?></td>
                            <td><?php echo e($data->phone); ?></td>
                            <td><?php echo e($data->status); ?></td>
                            <td>
                                <div class="d-flex align-items-center" style="gap: 5px">
                                    <a href="/resident/<?php echo e($data->id); ?>" class="d-inline-block btn btn-sm btn-warning">
                                        <i  class="fas fa-pen"></i>
                                    </a>
                                    <button class="btn btn-sm btn-danger" data-bs-toggle="modal" data-bs-target="#confirdelete-<?php echo e($data->id); ?>">
                                        <i  class="fas fa-eraser"></i>
                                    </button>
                                    <?php if(!is_null($data->user_id)): ?>
                                    <button class="btn btn-sm btn-outline-info" data-bs-toggle="modal" data-bs-target="#detailAccount-<?php echo e($data->id); ?>">
                                        Lihat Akun
                                    </button>
                                    <?php echo $__env->make('pages.resident.detail-account', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                                    <?php endif; ?>
                                </div>
                            </td>
                            </tr>
                            <?php echo $__env->make('pages.resident.confir-delete', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                    <?php endif; ?>
                </table>
            </div>
            <?php if($residents->lastPage()> 2): ?>
            <div class="card-footer">
                <?php echo e($residents->links('pagination::bootstrap-5')); ?>

            </div>
            <?php endif; ?>
            
        </div>
    </div>
    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\latihanlaravel\resources\views/pages/resident/index.blade.php ENDPATH**/ ?>