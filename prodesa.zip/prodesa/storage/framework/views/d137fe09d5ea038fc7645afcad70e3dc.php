

<?php $__env->startSection('content'); ?>
 <div class="d-sm-flex align-items-center justify-content-between mb-4">
    <h1 class="h3 mb-0 text-gray-800"><?php echo e(auth()->user()->role_id == \App\Models\Role::ROLE_USER ? 'Aduan' : 'Aduan Warga'); ?></h1>
      <?php if(isset(auth()->user()->resident)): ?>
          <a href="/complaint/create" class="d-none d-sm-inline-block btn btn-sm btn-primary shadow-sm"><i
         class="fas fa-plus fa-sm text-white-50"></i> Buat Aduan</a>
      <?php endif; ?>
    </div>

    <?php if(@session('success')): ?>
      <script>
        Swal.fire({
        title: "Berhasil",
        text: "<?php echo e(session()->get('success')); ?>",
        icon: "success"
        });
    </script>
    <?php endif; ?> 

    <?php if(@session('error')): ?>
      <script>
        Swal.fire({
        title: "Gagal",
        text: "<?php echo e(session()->get('error')); ?>",
        icon: "error"
        });
    </script>
    <?php endif; ?> 

    <div class="row">
        <div class="col">
            <div class="card shadow p-4">
                <div class="card-body">
                <table class="table table-responsive table-bordered table-hovered">
                    <thead>
                        <tr>
                            <th>No</th>
                            <?php if(auth()->user()->role_id == \App\Models\Role::ROLE_ADMIN): ?>
                                <th>Nama Penduduk</th>
                            <?php endif; ?>
                            <th>Judul</th>
                            <th>Isi Aduan</th>
                            <th>Status</th>
                            <th>Foto Bukti</th>
                            <th>Tanggal Ajuan</th>
                            <th>Aksi</th>
                        </tr>
                    </thead>
                    <?php if(count($complaints) == 0): ?>
                        <tbody>
                            <tr>
                                <td colspan="11">
                                    <p class="text-center">Tidak ada Data</p>
                                </td>
                            </tr>
                            <?php else: ?>
                            <tbody>
                        <?php $__currentLoopData = $complaints; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                
                        <tr>
                            <td><?php echo e($loop->iteration + $complaints->firstItem() - 1); ?></td>
                            <?php if(auth()->user()->role_id == \App\Models\Role::ROLE_ADMIN): ?>
                                <td><?php echo e($data->resident->name); ?></td>
                            <?php endif; ?>
                            <td><?php echo e($data->title); ?></td>
                            <td><?php echo wordwrap($data->content, 50, "<br>\n"); ?></td>
                            <td><span class="badge badge-<?php echo e($data->status_color); ?>"><?php echo e($data->status_label); ?></span></td>
                            <td>
                                <?php if(isset($data->photo_proof)): ?>
                                <?php
                                    $filePath = 'storage/' . $data->photo_proof;
                                ?>
                                    <a href="<?php echo e($filePath); ?>" rel="noopener noreferrer">
                                        <img src="<?php echo e($filePath); ?>" alt="Bukti Foto" style="max-width: 300px">
                                    </a>
                                    <?php else: ?>
                                    Tidak ada
                                <?php endif; ?>
                            </td>
                            <td><?php echo e($data->report_date_label); ?></td>
                            <td>
                                 <?php if( auth()->user()->role_id == \App\Models\Role::ROLE_USER && isset(auth()->user()->resident) && $data->status == 'new' ): ?>
                                <div class="d-flex align-items-center" style="gap: 5px">
                                    <a href="/complaint/<?php echo e($data->id); ?>" class="d-inline-block btn btn-sm btn-warning">
                                        <i  class="fas fa-pen"></i>
                                    </a>
                                    <button class="btn btn-sm btn-danger" data-bs-toggle="modal" data-bs-target="#confirdelete-<?php echo e($data->id); ?>">
                                        <i  class="fas fa-eraser"></i>
                                    </button>
                                </div>
                                <?php elseif(auth()->user()->role_id == \App\Models\Role::ROLE_ADMIN): ?>
                                <div>
                                    <form id="formChangeStatus-<?php echo e($data->id); ?>" action="/complaint/update-status/<?php echo e($data->id); ?>" method="post" style="min-width: 100px" oninput="document.getElementById('formChangeStatus-<?php echo e($data->id); ?>').submit()">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('POST'); ?>
                                    <div class="form-groub">
                                        <select name="status" id="status" class="form-control">
                                            <?php $__currentLoopData = [
                                                (object) [
                                                    'label' => 'Baru',
                                                    'value' => 'new',
                                        ],
                                                (object) [
                                                    'label' => 'Proses',
                                                    'value' => 'proccesing',
                                        ],
                                                (object) [
                                                    'label' => 'Selesai',
                                                    'value' => 'completed',
                                        ],
                                            ]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $status): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($status->value); ?>" <?php if($data->status == $status->value): echo 'selected'; endif; ?>><?php echo e($status->label); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                    </div>
                                </form>
                                </div>
                                <?php endif; ?>
                            </td> 
                            </tr>
                            <?php echo $__env->make('pages.complaint.confir-delete', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                    <?php endif; ?>
                </table>
            </div>
            <?php if($complaints->lastPage()> 2): ?>
            <div class="card-footer">
                <?php echo e($complaints->links('pagination::bootstrap-5')); ?>

            </div>
            <?php endif; ?>
            
        </div>
    </div>
    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\latihanlaravel\resources\views/pages/complaint/index.blade.php ENDPATH**/ ?>