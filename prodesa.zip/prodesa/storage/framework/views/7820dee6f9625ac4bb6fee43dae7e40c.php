<!-- Modal -->
<div class="modal fade" id="confirapprove-<?php echo e($data->id); ?>" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="confirapproveLabel" aria-hidden="true">
  <div class="modal-dialog">
    <form action="/account-request/approval/<?php echo e($data->id); ?>" method="post">
        <?php echo csrf_field(); ?>
        <?php echo method_field('POST'); ?>
        <div class="modal-content">
      <div class="modal-header">
        <h1 class="modal-title fs-5" id="confirapproveLabel">Konfirmasi Penerimaan</h1>
        <button type="button" class="btn btn-default" data-bs-dismiss="modal" aria-label="Close">
          <i class="fas fa-times">
          </i>
        </button>
      </div>
      
      <div class="modal-body">
        <input type="hidden" name="for" value="approve">
        <span>Yakin Menutujui Akun ini?</span>
        <div class="form-groub mt-3">
          <label for="user_id">Pilih Penduduk</label>
          <select name="user_id" id="user_id" class="form-control">
           <option value="">Tidak ada</option>
            <?php $__currentLoopData = $resident; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($data->id); ?>"><?php echo e($data->name); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </select>
        </div>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Tutup</button>
        <button type="submit" class="btn btn-outline-succes">Ya, Setujui</button>
      </div>
    </div>
    </form>
  </div>
</div><?php /**PATH C:\laragon\www\latihanlaravel\resources\views/pages/account-request/confir-approve.blade.php ENDPATH**/ ?>