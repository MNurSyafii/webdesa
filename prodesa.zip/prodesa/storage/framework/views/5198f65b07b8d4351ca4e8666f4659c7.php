<?php
    $menus = [
        1 => [
            (object)[
            'title' => 'Dashboard',
            'path' => 'dashboard',
            'icon' => 'fas fa-fw fa-tachometer-alt'
         ],
         (object)[
            'title' => 'Penduduk',
            'path' => 'resident',
            'icon' => 'fas fa-fw fa-table'
         ],
         (object)[
            'title' => 'Daftar Akun',
            'path' => 'account-list',
            'icon' => 'fas fa-fw fa-user'
         ],
         (object)[
            'title' => 'Permintaan Akun',
            'path' => 'account-request',
            'icon' => 'fas fa-fw fa-user'
         ],
         (object)[
            'title' => 'Aduan Warga',
            'path' => 'complaint',
            'icon' => 'fas fa-fw fa-scroll'
         ],
         (object)[
            'title' => 'Master RW',
            'path' => 'rw-unit',
            'icon' => 'fas fa-fw fa-tachometer-alt'
         ],
     ],
      2 => [
            (object)[
            'title' => 'Dashboard',
            'path' => 'dashboard',
            'icon' => 'fas fa-fw fa-tachometer-alt'
         ],
            (object)[
            'title' => 'Pengaduan',
            'path' => 'complaint',
            'icon' => 'fas fa-fw fa-scroll'
         ],
     ],
];
?>

<ul class="navbar-nav bg-gradient-primary sidebar sidebar-dark accordion" id="accordionSidebar">

            <!-- Sidebar - Brand -->
            <a class="sidebar-brand d-flex align-items-center justify-content-center" href="/dashboard">
                <div class="sidebar-brand-icon rotate-n-15">
                    <i></i>
                </div>
                <div class="sidebar-brand-text mx-3">ProDesa</div>
            </a>

            <!-- Divider -->
            <hr class="sidebar-divider my-0">

            <!-- Nav Item - Dashboard -->
            

            <!-- Divider -->
            

            <!-- Heading -->
            

            <!-- Nav Item - Tables -->
            <?php if(auth()->guard()->check()): ?>
                <?php $__currentLoopData = $menus [auth()->user()->role_id]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $menu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li class="nav-item  <?php echo e(request()->is($menu->path . '*')? 'active' : ''); ?>">
                <a class="nav-link" href="<?php echo e($menu->path); ?>">
                    <i class="<?php echo e($menu->icon); ?>"></i>
                    <span><?php echo e($menu->title); ?></span></a>
            </li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endif; ?>

            <!-- Divider -->
            <hr class="sidebar-divider d-none d-md-block">

            <!-- Sidebar Toggler (Sidebar) -->
            <div class="text-center d-none d-md-inline">
                <button class="rounded-circle border-0" id="sidebarToggle"></button>
            </div>

        </ul><?php /**PATH C:\laragon\www\latihanlaravel\resources\views/layouts/sidebar.blade.php ENDPATH**/ ?>