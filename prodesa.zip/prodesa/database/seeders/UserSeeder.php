<?php

namespace Database\Seeders;

use App\Models\Resident;
use App\Models\User;
use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;

class UserSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        User::create([
            'id' => 1,
            'name'=> 'Admin ProDesa',
            'email'=> 'admin@gmail.com',
            'password'=> 'admin12345',
            'status'=> 'approved',
            'role_id'=> 1, //=>admin
        ]);

        User::create([
            'id' => 2,
            'name'=> 'penduduk',
            'email'=> 'penduduk@gmail.com',
            'password'=> 'penduduk12345',
            'status'=> 'approved',
            'role_id'=> 2, //=>user
        ]);

        Resident::create([
            'user_id' => 2,
            'nik' => '3333333333333333',
            'name' => 'Farkhansyah',
            'gender' => 'male',
            'birth_date' => '2008-05-03',
            'birth_place' => 'Wanadadi',
            'addres' => 'Wanadadi',
            'marital_status' => 'single',
        ]);
    }
}
