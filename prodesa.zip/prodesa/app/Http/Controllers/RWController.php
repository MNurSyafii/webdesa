<?php

namespace App\Http\Controllers;

use App\Models\RwUnit;
use Illuminate\Http\Request;

class RWController extends Controller
{
    public function index()
    {
        $rw_units = RwUnit::paginate(5);

        
        return view('pages.rw-unit.index',[
            'rw_units' => $rw_units,
        ]);
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        return view('pages.rw-unit.create');
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        $validatedData = $request->validate([
            'number' => ['required', 'min:1', 'max:3'],
        ]);
        RwUnit::create($validatedData);
        return redirect('/rw-unit')->with('success', 'Data berhasil disimpan');
    }

    /**
     * Display the specified resource.
     */
    public function show(string $id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(string $id)
    {
        $rw_unit = RwUnit::findOrFail($id);
        return view('pages.rw-unit.edit',[
            'rw_unit' => $rw_unit,
        ]);
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, string $id)
    {
        $validatedData = $request->validate([
            'number' => ['required', 'min:1', 'max:3'],
        ]);
        RwUnit::findOrFail($id)->update($validatedData);

        return redirect('/rw-unit')->with('Succes');
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(string $id)
    {
        $rw_unit = RwUnit::findOrFail($id);
        $rw_unit->delete();
        
        return redirect('/rw-unit')->with('Succes');
    }
}
