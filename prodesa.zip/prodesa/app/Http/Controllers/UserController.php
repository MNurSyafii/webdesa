<?php

namespace App\Http\Controllers;

use App\Models\Resident;
use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;
use Illuminate\Validation\Rule;

class UserController extends Controller
{
    public function account_request_view(){
        $user = User::where('status', 'submited')->paginate(5);
        $resident = Resident::where('user_id', null)->get();

        return view('pages.account-request.index', [
            'users' => $user,
            'resident' => $resident,
        ]);
    }

    public function account_approval(Request $request, $userId){

        $request->validate([
            'for' => ['required', Rule::in('approve', 'reject', 'active', 'deactive')],
            'resident_id' => ['nullable', 'exists:residents,id'],
        ]);

        $for = $request->input('for');

        $user = User::findOrFail($userId);
        if ($for == 'approve' || $for == 'active') {
            $user->status = 'approved';
        } elseif ($for == 'deactive') {
            $user->status = 'deactive';
        } else {
            $user->status = 'rejected';
        }

        $user->save();



        $residentId = $request->input('resident_id');

        if($request->has('resident_id') && isset($residentId)){
            Resident::where('id', $residentId)->update([
                'user_id' => $user->id,
            ]);
        }

        if($for == 'active'){
            return back()->with('success', 'Berhasil mengaktifkan akun');
        }elseif($for == 'deactive'){
            return back()->with('success', 'Berhasil mennonaktifkan akun');
        }

        return back()->with('success', $for == 'approved' ? 'Berhasil menambahkan akun' : 'Berhasil menolak akun');
    }

    public function account_list_view(){
        $user = User::where('role_id', '2')->where('status', '!=', 'submited')->paginate(5);

        return view('pages.account-list.index', [
            'user' => $user,
        ]);
    }

    public function profile_view(){
        return view('pages.profile.index');
    }

    public function update_profile(Request $request, $userId){
        $request->validate([
            'name' => 'required|min:3',
        ]);

        $user = User::findOrFail($userId);
        $user->name = $request->name;
        $user->save();

        return back()->with('success', 'Berhasil mengubah data akun');
    }

    public function change_password_view(){
        return view('pages.profile.change-password');
    }

    public function change_password(Request $request, $userId){
    $request->validate([
        'old_password' => 'required|min:8',
        'new_password' => 'required|min:8',
    ]);

    $user = User::findOrFail($userId); // Pindah ke atas dulu agar bisa dipakai di Hash::check

    $currentpasswordIsValid = Hash::check($request->input('old_password'), $user->password);

    if ($currentpasswordIsValid) {
        $user->password = Hash::make($request->input('new_password')); // Perlu di-hash
        $user->save();
        return back()->with('success', 'Berhasil mengubah data password');
    }

    return back()->with('error', 'Gagal mengubah data password');
}

}
