<?php

namespace App\Models;

use Carbon\Carbon;
use Illuminate\Database\Eloquent\Model;

class Complaint extends Model
{
    protected $guarded = [];

    public function getStatusLabelAttribute() //status_label
    { 
        return match ($this->status){
            'new' => 'Baru',
            'proccesing' => 'Proses',
            'completed' => 'Selesai',
            default => 'Tidak di Ketahui',
        };
    }

    public function getReportDateLabelAttribute() //report_date_label
    {
        return \Carbon\Carbon::parse($this->report_date)->format('d M Y H:i:s');
    }

    public function getStatusColorAttribute() //status_color
    {
         return match ($this->status){
            'new' => 'info',
            'proccesing' => 'warning',
            'completed' => 'success',
            default => 'secondary',
        };
    }

    public function resident()
    {
        return $this->belongsTo(Resident::class);
    }
}
