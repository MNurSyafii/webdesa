@extends('layouts.app')

@section('content')
 <div class="d-sm-flex align-items-center justify-content-between mb-4">
    <h1 class="h3 mb-0 text-gray-800">List RW</h1>
          <a href="/rw-unit/create" class="d-none d-sm-inline-block btn btn-sm btn-primary shadow-sm"><i
         class="fas fa-plus fa-sm text-white-50"></i> Tambah </a>
    </div>

    @if (@session('success'))
      <script>
        Swal.fire({
        title: "Berhasil",
        text: "{{ session()->get('success')}}",
        icon: "success"
        });
    </script>
    @endif 

    @if (@session('error'))
      <script>
        Swal.fire({
        title: "Gagal",
        text: "{{ session()->get('error')}}",
        icon: "error"
        });
    </script>
    @endif 

    <div class="row">
        <div class="col">
            <div class="card shadow p-4">
                <div class="card-body">
                <table class="table table-bordered table-hovered" style="min-width: 100%">
                    <thead>
                        <tr>
                            <th>No</th>
                            <th>RW (Nomor)</th>
                            <th>Aksi</th>
                        </tr>
                    </thead>
                    @if (count($rw_units) < 1)
                        <tbody>
                            <tr>
                                <td colspan="11">
                                    <p class="text-center">Tidak ada Data</p>
                                </td>
                            </tr>
                            @else
                            <tbody>
                        @foreach ($rw_units as $data)
                
                        <tr>
                            <td>{{ $loop->iteration + $rw_units->firstItem() - 1 }}</td>
                            <td>RW {{$data->number}}</td>
                            <td>
                                <div class="d-flex align-items-center" style="gap: 5px">
                                    <a href="/rw-unit/{{$data->id}}" class="d-inline-block btn btn-sm btn-warning">
                                        <i  class="fas fa-pen"></i>
                                    </a>
                                    <button class="btn btn-sm btn-danger" data-bs-toggle="modal" data-bs-target="#confirdelete-{{ $data->id }}">
                                        <i  class="fas fa-eraser"></i>
                                    </button>
                                </div>
                            </td> 
                            </tr>
                            @include('pages.rw-unit.confir-delete')
                            @endforeach
                    </tbody>
                    @endif
                </table>
            </div>
            @if($rw_units->lastPage()> 2)
            <div class="card-footer">
                {{$rw_units->links('pagination::bootstrap-5')}}
            </div>
            @endif
            
        </div>
    </div>
    </div>

@endsection