@extends('layouts.app')

@section('content')
    <div class="d-sm-flex align-items-center justify-content-between mb-4">
    <h1 class="h3 mb-0 text-gray-800">Tambah RW</h1>
    </div>

    {{-- @if ($errors->any())
       @dd($errors->all()) 
    @endif --}}

    <div class="row">
        <div class="col">
            <form action="/rw-unit" method="post" enctype="multipart/form-data">
                @csrf
                @method('POST')
            <div class="card">
                <div class="card-body">
                    <div class="form-group mb-3">
                        <label for="number">Nomor RW</label>
                        <input type="text" id="number" class="form-control @error ('number') is-invalid @enderror" name="number" placeholder="masukan nomor rw" value="{{ old('number')}}">
                        @error('number')
                            <span class="invalid-feedback">
                                {{ $message }}
                            </span>
                        @enderror
                    </div>
                <div class="card-footer">
                    <div class="d-flex justify-content-end">
                        <a href="/rw-unit" class="d-inline-block mr-1 btn btn-outline-secondary">
                            Kembali
                        </a>
                        <button type="submit" class="btn btn-primary"> 
                            Simpan
                        </button>
                    </div>
                </div>
            </div>
            </form>
        </div>
    </div>
@endsection