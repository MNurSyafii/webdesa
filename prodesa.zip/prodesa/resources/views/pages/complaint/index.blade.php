@extends('layouts.app')

@section('content')
 <div class="d-sm-flex align-items-center justify-content-between mb-4">
    <h1 class="h3 mb-0 text-gray-800">{{auth()->user()->role_id == \App\Models\Role::ROLE_USER ? 'Aduan' : 'Aduan Warga'}}</h1>
      @if (isset(auth()->user()->resident))
          <a href="/complaint/create" class="d-none d-sm-inline-block btn btn-sm btn-primary shadow-sm"><i
         class="fas fa-plus fa-sm text-white-50"></i> Buat Aduan</a>
      @endif
    </div>

    @if (@session('success'))
      <script>
        Swal.fire({
        title: "Berhasil",
        text: "{{ session()->get('success')}}",
        icon: "success"
        });
    </script>
    @endif 

    @if (@session('error'))
      <script>
        Swal.fire({
        title: "Gagal",
        text: "{{ session()->get('error')}}",
        icon: "error"
        });
    </script>
    @endif 

    <div class="row">
        <div class="col">
            <div class="card shadow p-4">
                <div class="card-body">
                <table class="table table-responsive table-bordered table-hovered">
                    <thead>
                        <tr>
                            <th>No</th>
                            @if (auth()->user()->role_id == \App\Models\Role::ROLE_ADMIN)
                                <th>Nama Penduduk</th>
                            @endif
                            <th>Judul</th>
                            <th>Isi Aduan</th>
                            <th>Status</th>
                            <th>Foto Bukti</th>
                            <th>Tanggal Ajuan</th>
                            <th>Aksi</th>
                        </tr>
                    </thead>
                    @if (count($complaints) == 0)
                        <tbody>
                            <tr>
                                <td colspan="11">
                                    <p class="text-center">Tidak ada Data</p>
                                </td>
                            </tr>
                            @else
                            <tbody>
                        @foreach ($complaints as $data)
                
                        <tr>
                            <td>{{ $loop->iteration + $complaints->firstItem() - 1 }}</td>
                            @if (auth()->user()->role_id == \App\Models\Role::ROLE_ADMIN)
                                <td>{{$data->resident->name}}</td>
                            @endif
                            <td>{{$data->title}}</td>
                            <td>{!! wordwrap($data->content, 50, "<br>\n") !!}</td>
                            <td><span class="badge badge-{{$data->status_color}}">{{$data->status_label}}</span></td>
                            <td>
                                @if (isset($data->photo_proof))
                                @php
                                    $filePath = 'storage/' . $data->photo_proof;
                                @endphp
                                    <a href="{{$filePath}}" rel="noopener noreferrer">
                                        <img src="{{$filePath}}" alt="Bukti Foto" style="max-width: 300px">
                                    </a>
                                    @else
                                    Tidak ada
                                @endif
                            </td>
                            <td>{{$data->report_date_label}}</td>
                            <td>
                                 @if ( auth()->user()->role_id == \App\Models\Role::ROLE_USER && isset(auth()->user()->resident) && $data->status == 'new' )
                                <div class="d-flex align-items-center" style="gap: 5px">
                                    <a href="/complaint/{{$data->id}}" class="d-inline-block btn btn-sm btn-warning">
                                        <i  class="fas fa-pen"></i>
                                    </a>
                                    <button class="btn btn-sm btn-danger" data-bs-toggle="modal" data-bs-target="#confirdelete-{{ $data->id }}">
                                        <i  class="fas fa-eraser"></i>
                                    </button>
                                </div>
                                @elseif (auth()->user()->role_id == \App\Models\Role::ROLE_ADMIN)
                                <div>
                                    <form id="formChangeStatus-{{$data->id}}" action="/complaint/update-status/{{$data->id}}" method="post" style="min-width: 100px" oninput="document.getElementById('formChangeStatus-{{$data->id}}').submit()">
                                    @csrf
                                    @method('POST')
                                    <div class="form-groub">
                                        <select name="status" id="status" class="form-control">
                                            @foreach ([
                                                (object) [
                                                    'label' => 'Baru',
                                                    'value' => 'new',
                                        ],
                                                (object) [
                                                    'label' => 'Proses',
                                                    'value' => 'proccesing',
                                        ],
                                                (object) [
                                                    'label' => 'Selesai',
                                                    'value' => 'completed',
                                        ],
                                            ] as $status)
                                                <option value="{{$status->value}}" @selected($data->status == $status->value)>{{$status->label}}</option>
                                            @endforeach
                                        </select>
                                    </div>
                                </form>
                                </div>
                                @endif
                            </td> 
                            </tr>
                            @include('pages.complaint.confir-delete')
                            @endforeach
                    </tbody>
                    @endif
                </table>
            </div>
            @if($complaints->lastPage()> 2)
            <div class="card-footer">
                {{$complaints->links('pagination::bootstrap-5')}}
            </div>
            @endif
            
        </div>
    </div>
    </div>

@endsection