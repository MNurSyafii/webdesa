@extends('layouts.app')

@section('content')
 <div class="d-sm-flex align-items-center justify-content-between mb-4">
    <h1 class="h3 mb-0 text-gray-800">Data Penduduk</h1>
      <a href="/resident/create" class="d-none d-sm-inline-block btn btn-sm btn-primary shadow-sm"><i
         class="fas fa-plus fa-sm text-white-50"></i> Tambah </a>
    </div>

    <div class="row">
        <div class="col">
            <div class="card shadow p-4">
                <div class="card-body">
                <table class="table table-responsive table-bordered table-hovered">
                    <thead>
                        <tr>
                            <th>No</th>
                            <th>NIK</th>
                            <th>Nama</th>
                            <th>Jenis Kelamin</th>
                            <th>TTL</th>
                            <th>Alamat</th>
                            <th>Agama</th>
                            <th>Status Perkawinan</th>
                            <th>Pekerjaan</th>
                            <th>Telepon</th>
                            <th>Status Penduduk</th>
                            <th>Aksi</th>
                        </tr>
                    </thead>
                    @if (count($residents) == 0)
                        <tbody>
                            <tr>
                                <td colspan="11">
                                    <p class="text-center">Tidak ada Data</p>
                                </td>
                            </tr>
                            @else
                            <tbody>
                        @foreach ($residents as $data)
                
                        <tr>
                            <td>{{ $loop->iteration + $residents->firstItem() - 1 }}</td>
                            <td>{{$data->nik}}</td>
                            <td>{{$data->name}}</td>
                            <td>{{$data->gender}}</td>
                            <td>{{$data->birth_place}}, {{$data->birth_date}}</td>
                            <td>{{$data->addres}}</td>
                            <td>{{$data->religion}}</td>
                            <td>{{$data->marital_status}}</td>
                            <td>{{$data->occupation}}</td>
                            <td>{{$data->phone}}</td>
                            <td>{{$data->status}}</td>
                            <td>
                                <div class="d-flex align-items-center" style="gap: 5px">
                                    <a href="/resident/{{$data->id}}" class="d-inline-block btn btn-sm btn-warning">
                                        <i  class="fas fa-pen"></i>
                                    </a>
                                    <button class="btn btn-sm btn-danger" data-bs-toggle="modal" data-bs-target="#confirdelete-{{ $data->id }}">
                                        <i  class="fas fa-eraser"></i>
                                    </button>
                                    @if (!is_null($data->user_id))
                                    <button class="btn btn-sm btn-outline-info" data-bs-toggle="modal" data-bs-target="#detailAccount-{{ $data->id }}">
                                        Lihat Akun
                                    </button>
                                    @include('pages.resident.detail-account')
                                    @endif
                                </div>
                            </td>
                            </tr>
                            @include('pages.resident.confir-delete')
                            @endforeach
                    </tbody>
                    @endif
                </table>
            </div>
            @if($residents->lastPage()> 2)
            <div class="card-footer">
                {{$residents->links('pagination::bootstrap-5')}}
            </div>
            @endif
            
        </div>
    </div>
    </div>

@endsection