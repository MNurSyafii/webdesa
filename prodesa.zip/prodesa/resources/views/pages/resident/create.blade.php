@extends('layouts.app')

@section('content')
    <div class="d-sm-flex align-items-center justify-content-between mb-4">
    <h1 class="h3 mb-0 text-gray-800">Tambah Penduduk</h1>
    </div>

    {{-- @if ($errors->any())
       @dd($errors->all()) 
    @endif --}}

    <div class="row">
        <div class="col">
            <form action="/resident" method="post">
                @csrf
                @method('POST')
            <div class="card">
                <div class="card-body">
                    <div class="form-group mb-3">
                        <label for="nik">NIK</label>
                        <input type="number" inputmode="numeric" id="nik" class="form-control @error ('nik') is-invalid @enderror" name="nik" placeholder="masukan nik" value="{{ old('nik')}}">
                        @error('nik')
                            <span class="invalid-feedback">
                                {{ $message }}
                            </span>
                        @enderror
                    </div>
                    <div class="form-group mb-3">
                        <label for="name">Nama</label>
                        <input type="text" id="name" class="form-control @error ('name') is-invalid @enderror" name="name" placeholder="masukan nama" value="{{ old('name')}}" >
                        @error('name')
                            <span class="invalid-feedback">
                                {{ $message }}
                            </span>
                        @enderror
                    </div>
                    <div class="form-group mb-3">
                        <label for="gender">Jenis Kelamin</label>
                        <select name="gender" id="gender" class="form-control @error ('gender') is-invalid @enderror" >
                            <option value="male">Laki-laki</option>
                            <option value="female">Perempuan</option>
                        </select>
                        @error('gender')
                            <span class="invalid-feedback">
                                {{ $message }}
                            </span>
                        @enderror
                    </div>
                    <div class="form-group mb-3">
                        <label for="birth_date">Tanggal Lahir</label>
                        <input type="date" id="birth_date" class="form-control @error ('birth_date') is-invalid @enderror" name="birth_date" placeholder="masukan tanggal lahir" value="{{ old('birth_date') }}">
                        @error('birth_date')
                            <span class="invalid-feedback">
                                {{ $message }}
                            </span>
                        @enderror
                    </div>
                    <div class="form-group mb-3">
                        <label for="birth_place">Tempat Lahir</label>
                        <input type="text" id="birth_place" class="form-control @error ('birth_place') is-invalid @enderror" name="birth_place" placeholder="masukan tempat lahir"  value="{{ old('birth_place')}}">
                        @error('birth_place')
                            <span class="invalid-feedback">
                                {{ $message }}
                            </span>
                        @enderror
                    </div>
                    <div class="form-group mb-3">
                        <label for="religion">Agama</label>
                        <input type="text" id="religion" class="form-control @error ('religion') is-invalid @enderror" name="religion" placeholder="masukan agama"  value="{{ old('religion')}}" >
                        @error('religion')
                            <span class="invalid-feedback">
                                {{ $message }}
                            </span>
                        @enderror
                    </div>
                    <div class="form-group mb-3">
                        <label for="addres">Alamat</label>
                        <textarea name="addres" id="addres" cols="10" rows="10" class="form-control  @error ('addres') is-invalid @enderror" placeholder="masukan alamat"  value="{{ old('addres')}}" ></textarea>
                        @error('addres')
                            <span class="invalid-feedback">
                                {{ $message }}
                            </span>
                        @enderror
                    </div>
                    <div class="form-group mb-3">
                        <label for="marital_status">Status Perkawinan</label>
                        <select name="marital_status" id="marital_status" class="form-control  @error ('marital_status') is-invalid @enderror" >
                            <option value="single">Belum Menikah</option>
                            <option value="married">Menikah</option>
                            <option value="divorced">Cerai</option>
                            <option value="widowed">Janda/Duda</option>
                        </select>
                        @error('marital_status')
                            <span class="invalid-feedback">
                                {{ $message }}
                            </span>
                        @enderror
                    </div>
                    <div class="form-group mb-3">
                        <label for="occupation">Pekerjaan</label>
                        <input type="text" id="occupation" class="form-control  @error ('occupation') is-invalid @enderror" name="occupation" placeholder="masukan pekerjaan"  value="{{ old('occuption')}}">
                        @error('occupation')
                            <span class="invalid-feedback">
                                {{ $message }}
                            </span>
                        @enderror
                    </div>
                    <div class="form-group mb-3">
                        <label for="phone">telepon</label>
                        <input type="number" inputmode="numeric" id="phone" class="form-control  @error ('phone') is-invalid @enderror" name="phone" placeholder="masukan telepon"  value="{{ old('phone')}}" >
                        @error('telepon')
                            <span class="invalid-feedback">
                                {{ $message }}
                            </span>
                        @enderror
                    </div>
                    <div class="form-group mb-3">
                        <label for="status">Status</label>
                        <select name="status" id="status" class="form-control  @error ('status') is-invalid @enderror" >
                            <option value="active">Aktif</option>
                            <option value="moved">Pindah</option>
                            <option value="deceased">Meninggal</option>
                        </select>
                        @error('status')
                            <span class="invalid-feedback">
                                {{ $message }}
                            </span>
                        @enderror
                </div>
                <div class="card-footer">
                    <div class="d-flex justify-content-end">
                        <a href="/resident" class="d-inline-block mr-1 btn btn-outline-secondary">
                            Kembali
                        </a>
                        <button type="submit" class="btn btn-primary"> 
                            Simpan
                        </button>
                    </div>
                </div>
            </div>
            </form>
        </div>
    </div>
@endsection