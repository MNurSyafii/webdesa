@extends('layouts.app')

@section('content')
 <div class="d-sm-flex align-items-center justify-content-between mb-4">
    <h1 class="h3 mb-0 text-gray-800">Permintaan Akun</h1>
    </div>

    @if (@session('success'))
      <script>
        Swal.fire({
        title: "Berhasil",
        text: "{{ session()->get('success')}}",
        icon: "success"
        });
    </script>
    @endif 

    <div class="row">
        <div class="col">
            <div class="card shadow p-4">
                <div class="card-body">
                    <div style="overflow-x: auto">
                <table class="table table-bordered table-hovered" style="min-width: 100%">
                    <thead>
                        <tr>
                            <th>No</th>
                            <th>Nama</th>
                            <th>Email</th>
                            <th>Aksi</th>
                        </tr>
                    </thead>
                    @if (count($users) == 0)
                        <tbody>
                            <tr>
                                <td colspan="11">
                                    <p class="text-center">Tidak ada Data</p>
                                </td>
                            </tr>
                            @else
                            <tbody>
                        @foreach ($users as $data)
                
                        <tr>
                            <td>{{ $loop->iteration + $users->firstItem() - 1 }}</td>
                            <td>{{$data->name}}</td>
                            <td>{{$data->email}}</td>
                            <td>
                                <div class="d-flex" style="gap: 5px">
                                    <button class="btn btn-sm btn-success" data-bs-toggle="modal" data-bs-target="#confirapprove-{{ $data->id }}">
                                       Setujui
                                    </button>
                                    <button class="btn btn-sm btn-danger" data-bs-toggle="modal" data-bs-target="#confirreject-{{ $data->id }}">
                                       Tolak
                                    </button>
                                </div>
                            </td>
                            </tr>
                            @include('pages.account-request.confir-approve')
                            @include('pages.account-request.confir-reject')
                            @endforeach
                    </tbody>
                    @endif
                </table>
                </div>
            </div>
             @if($users->lastPage()> 2)
            <div class="card-footer">
                {{$users->links('pagination::bootstrap-5')}}
            </div>
            @endif
            
        </div>
    </div>
    </div>

@endsection