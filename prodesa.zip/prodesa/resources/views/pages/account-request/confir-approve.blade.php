<!-- Modal -->
<div class="modal fade" id="confirapprove-{{ $data->id }}" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="confirapproveLabel" aria-hidden="true">
  <div class="modal-dialog">
    <form action="/account-request/approval/{{$data->id}}" method="post">
        @csrf
        @method('POST')
        <div class="modal-content">
      <div class="modal-header">
        <h1 class="modal-title fs-5" id="confirapproveLabel">Konfirmasi Penerimaan</h1>
        <button type="button" class="btn btn-default" data-bs-dismiss="modal" aria-label="Close">
          <i class="fas fa-times">
          </i>
        </button>
      </div>
      
      <div class="modal-body">
        <input type="hidden" name="for" value="approve">
        <span>Yakin Menutujui Akun ini?</span>
        <div class="form-groub mt-3">
          <label for="resident_id">Pilih Penduduk</label>
          <select name="resident_id" id="resident_id" class="form-control">
           <option value="">Tidak ada</option>
            @foreach ($resident as $data)
                <option value="{{$data->id}}">{{$data->name}}</option>
            @endforeach
          </select>
        </div>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Tutup</button>
        <button type="submit" class="btn btn-outline-succes">Ya, Setujui</button>
      </div>
    </div>
    </form>
  </div>
</div>