<?php

use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Route;
use App\Http\Controllers\AuthController;
use App\Http\Controllers\UserController;
use App\Http\Controllers\ResidentController;
use App\Http\Controllers\ComplaintController;
use App\Http\Controllers\RWController;

    Route::middleware('guest')->group(function () {
    Route::get('/', [AuthController::class, 'login']);
    Route::get('/login', [AuthController::class, 'login'])->name('login');
    Route::post('/login', [AuthController::class, 'authenticate']);
    Route::get('/register', [AuthController::class, 'registerView']);
    Route::post('/register', [AuthController::class, 'register']);
});

    Route::middleware('auth')->group(function () {
    Route::post('/logout', [AuthController::class, 'logout']);

    Route::get('/dashboard', function () {
        return view('pages.dashboard');
    })->middleware('role:Admin,User');

    Route::get('/notifications', function() {
        return view('pages.notifications');
    });

    Route::post('/notification/{id}/read', function ($id) {
    // Ambil data notifikasi
    $notification = DB::table('notifications')
        ->where('id', $id)
        ->first();
    
    // Cek apakah notifikasi sudah dibaca
    if ($notification && is_null($notification->read_at)) {
        // Update status notifikasi menjadi sudah dibaca
        DB::table('notifications')
            ->where('id', $id)
            ->update([
                'read_at' => now()
            ]);
        
        // Jika belum dibaca dan memiliki complaint_id, arahkan ke halaman complaint
        $decodedData = json_decode($notification->data);
        if (isset($decodedData->complaint_id)) {
            return redirect('/complaint');
        }
    }

    // Jika sudah dibaca atau tidak memiliki complaint_id, kembali ke halaman sebelumnya
    return back();
    })->middleware('role:Admin,User');

    Route::get('/resident', [ResidentController::class, 'index'])->middleware('role:Admin');
    Route::get('/resident/create', [ResidentController::class, 'create'])->middleware('role:Admin');
    Route::get('/resident/{id}', [ResidentController::class, 'edit'])->middleware('role:Admin');
    Route::post('/resident', [ResidentController::class, 'store'])->middleware('role:Admin');
    Route::put('/resident/{id}', [ResidentController::class, 'update'])->middleware('role:Admin');
    Route::delete('/resident/{id}', [ResidentController::class, 'destroy'])->middleware('role:Admin');

    Route::get('/account-list', [UserController::class, 'account_list_view'])->middleware('role:Admin');

    Route::get('/account-request', [UserController::class, 'account_request_view'])->middleware('role:Admin');
    Route::post('/account-request/approval/{id}', [UserController::class, 'account_approval'])->middleware('role:Admin');

    Route::get('/profile', [UserController::class, 'profile_view'])->middleware('role:Admin, User');
    Route::post('/profile/{id}', [UserController::class, 'update_profile'])->middleware('role:Admin, User');
    Route::get('/change-password', [UserController::class, 'change_password_view'])->middleware('role:Admin, User');
    Route::post('/change-password/{id}', [UserController::class, 'change_password'])->middleware('role:Admin, User');

    Route::get('/complaint', [ComplaintController::class, 'index'])->middleware('role:Admin,User');
    Route::get('/complaint/create', [ComplaintController::class, 'create'])->middleware('role:User');
    Route::get('/complaint/{id}', [ComplaintController::class, 'edit'])->middleware('role:User');
    Route::post('/complaint', [ComplaintController::class, 'store'])->middleware('role:User');
    Route::put('/complaint/{id}', [ComplaintController::class, 'update'])->middleware('role:User');
    Route::delete('/complaint/{id}', [ComplaintController::class, 'destroy'])->middleware('role:User');
    Route::post('/complaint/update-status/{id}', [ComplaintController::class, 'update_status'])->middleware('role:Admin');

    Route::get('/rw-unit', [RWController::class, 'index'])->middleware('role:Admin');
    Route::get('/rw-unit/create', [RWController::class, 'create'])->middleware('role:Admin');
    Route::get('/rw-unit/{id}', [RWController::class, 'edit'])->middleware('role:Admin');
    Route::post('/rw-unit', [RWController::class, 'store'])->middleware('role:Admin');
    Route::put('/rw-unit/{id}', [RWController::class, 'update'])->middleware('role:Admin');
    Route::delete('/rw-unit/{id}', [RWController::class, 'destroy'])->middleware('role:Admin');

});